import { mkdir, readFile, writeFile } from 'node:fs/promises';
const assetSources = {
  '/': ['text/html; charset=utf-8', 'index.html'],
  '/inspira/rimas': ['text/html; charset=utf-8', 'inspira-rimas.html'],
  '/inspira/ebook-autoral': ['text/html; charset=utf-8', 'inspira-ebook.html'],
  '/estilos.css': ['text/css; charset=utf-8', 'estilos.css'],
  '/miudoverso.js': ['text/javascript; charset=utf-8', 'miudoverso.js'],
  '/marca.webp': ['image/webp', 'assets/marca.webp', 'base64'],
  '/simbolo.webp': ['image/webp', 'assets/simbolo.webp', 'base64'],
  '/cartas-de-rimas.pdf': ['application/pdf', 'assets/cartas-de-rimas.pdf', 'base64', 'miudoverso-cartas-de-rimas.pdf']
};
const files = {};
for (const [url, [type, file, encoding = 'utf8', filename]] of Object.entries(assetSources)) {
  files[url] = [type, await readFile(file, encoding), encoding === 'base64', filename];
}
await mkdir('dist/server', { recursive: true });
await writeFile('dist/server/index.js', 'const files = ' + JSON.stringify(files) + ';\n' + await readFile('worker.mjs', 'utf8'));
