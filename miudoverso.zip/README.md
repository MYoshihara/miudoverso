# Miudoverso

Prévia de validação com catálogo, perfis, lojinhas demonstrativas, artigos e lista de espera.

## Executar no computador

Use Node.js 24 e rode estes comandos na pasta `miudoverso`.

```sh
npm run build
npm run preview
```

Abra o endereço indicado no terminal. Os cadastros locais são gravados em `inscricoes.sqlite`. O arquivo é criado na primeira execução e permanece no computador.

Para consultar as inscrições locais com o utilitário SQLite:

```sh
sqlite3 -header -column inscricoes.sqlite 'SELECT email, area, interesse, inscrito_em FROM waitlist ORDER BY inscrito_em DESC;'
```

## Publicação

O Worker é gerado em `dist/server/index.js`. O manifesto de hospedagem está em `.openai/hosting.json`. Aplique a migração em `drizzle/` para criar a lista de espera no banco da hospedagem.

Cadastros no ambiente local ficam no SQLite local. Cadastros de uma futura implantação ficam no D1 com o binding DB. Perfis, publicação de materiais, denúncias e compras são demonstrações. A ficha em PDF pode ser baixada.
