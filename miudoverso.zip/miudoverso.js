
const materials = [
  { id:'rimas', title:'Cartas de rimas', author:'Lia Martins', area:'pedagogia', label:'Pedagogia', art:'Aa', color:'violet', type:'Ficha em PDF', description:'Cartas recortáveis para reconhecer palavras que terminam com sons parecidos.' },
  { id:'historias', title:'Sequências para contar histórias', author:'Bia Costa', area:'fonoaudiologia', label:'Fonoaudiologia', art:'1·2·3', color:'mint', type:'Caderno', price:'R$ 19,90', description:'Atividades para ordenar acontecimentos, descrever ações e recontar uma história.' },
  { id:'palavras', title:'Brincar com as palavras', author:'Rafa Nunes', area:'pedagogia', label:'Pedagogia', art:'A+B', color:'honey', type:'E-book', price:'R$ 29,90', description:'Brincadeiras com letras, palavras e histórias para atividades de alfabetização.' }
];
const people = [
  { name:'Lia Martins', initials:'LM', role:'Pedagoga', bio:'Propostas de alfabetização e aprendizagem para os primeiros anos.' },
  { name:'Bia Costa', initials:'BC', role:'Fonoaudióloga', bio:'Recursos para trabalhar linguagem oral e construção de narrativas.' },
  { name:'Rafa Nunes', initials:'RN', role:'Pedagogo', bio:'Brincadeiras e experiências de leitura pensadas para trabalhar em grupo.' }
];
const bookmark = '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M6 4h12v16l-6-4-6 4z" stroke-linejoin="round"/></svg>';
const grid = document.querySelector('#resources');
const query = document.querySelector('#search');
const dialog = document.querySelector('#dialog');
const dialogBody = document.querySelector('#dialog-body');
const saved = loadFavorites();
let selectedFilter = 'todos';

function loadFavorites() {
  try {
    const values = JSON.parse(localStorage.getItem('miudoverso:saved') || '[]');
    if (Array.isArray(values)) return new Set(values.filter(id => materials.some(item => item.id === id)));
  } catch {}
  return new Set();
}
function comparable(value) {
  return value.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().trim();
}
function renderCatalog() {
  const term = comparable(query.value);
  const shown = materials.filter(item => {
    const matchesTerm = comparable(item.title + ' ' + item.author + ' ' + item.label + ' ' + item.description + ' ' + item.type).includes(term);
    const matchesFilter = selectedFilter === 'todos' || selectedFilter === item.area || (selectedFilter === 'gratuitos' && !item.price);
    return matchesTerm && matchesFilter;
  });
  const count = shown.length;
  document.querySelector('#result').textContent = count === 0 ? 'Nenhum material encontrado.' : count + (count === 1 ? ' material encontrado' : ' materiais encontrados');
  grid.innerHTML = shown.map(item => '<article class="resource">' +
    '<div class="cover ' + item.color + '"><div class="mini-sheet" aria-hidden="true"><strong>' + item.art + '</strong><small>' + item.type + '</small></div>' +
    '<span class="tag">' + (item.price || 'Gratuito') + '</span><button class="save" type="button" data-save="' + item.id +
    '" aria-label="Favoritar ' + item.title + '" aria-pressed="' + saved.has(item.id) + '">' + bookmark + '</button></div>' +
    '<div class="card-copy"><p class="label">' + item.label + ' · ' + item.author + '</p><h3>' + item.title + '</h3><p>' + item.description +
    '</p><button class="text-link" type="button" data-item="' + item.id + '">Ver material</button></div></article>').join('');
}

function show(title, contents) {
  document.querySelector('#dialog-title').textContent = title;
  dialogBody.innerHTML = contents;
  if (!dialog.open) dialog.showModal();
  dialog.querySelector('.close').focus();
}
function openMaterial(id) {
  const item = materials.find(entry => entry.id === id);
  const action = item.price
    ? '<p><strong>' + item.price + '</strong> · Preço de exemplo.</p><button class="button primary" type="button" data-buy>Simular interesse na compra</button><p class="feedback" role="status"></p>'
    : '<a class="button primary" href="/cartas-de-rimas.pdf">Baixar ficha em PDF</a>';
  show(item.title, '<p class="label">' + item.type + ' · ' + item.author + '</p><p>' + item.description + '</p>' +
    action + '<button class="text-link" type="button" data-report>Simular denúncia</button>');
}
function listLinks(items) {
  return '<ul>' + items.map(item => '<li><button class="text-link" type="button" data-item="' + item.id + '">' + item.title + '</button></li>').join('') + '</ul>';
}
function viewProfile(index) {
  const person = people[index];
  show(person.name, '<p class="label">' + person.role + ' · Perfil demonstrativo</p><p>' + person.bio + '</p><h3>Lojinha</h3>' +
    listLinks(materials.filter(item => item.author === person.name)));
}
function viewFavorites() {
  const favorites = materials.filter(item => saved.has(item.id));
  const contents = favorites.length ? listLinks(favorites) : '<p>Use o ícone de favorito nos materiais para encontrá-los aqui.</p>';
  show('Meu Miudoverso', '<p class="label">Materiais salvos neste navegador</p>' + contents +
    '<button type="button" class="button outlined" id="profile-preview">Simular meu perfil</button>');
}
function publish() {
  show('Publicar material', '<p>Experimente o envio. O arquivo selecionado fica no seu dispositivo.</p><form class="form" id="publish-form">' +
    '<label>Título do material<input name="title" maxlength="90" required></label>' +
    '<label>Tipo<select name="type"><option>Atividade gratuita</option><option>Material pago</option><option>E-book pago</option></select></label>' +
    '<label>Selecionar PDF<input name="file" type="file" accept=".pdf,application/pdf" required></label>' +
    '<label class="check"><input type="checkbox" required> <span>Confirmo que o material é autoral ou que tenho autorização para distribuí-lo.</span></label>' +
    '<button type="submit" class="button primary">Simular envio para revisão</button><p class="feedback" role="status"></p></form>');
}
function report() {
  show('Denunciar material', '<form class="form" id="report-form"><label>Motivo<select name="reason" required><option value="">Selecione o motivo</option>' +
    '<option>Possível cópia sem autorização</option><option>Conteúdo inadequado</option><option>Outro motivo</option></select></label>' +
    '<button class="button primary" type="submit">Simular denúncia</button><p class="feedback" role="status"></p></form>');
}
function editProfile() {
  show('Meu perfil profissional', '<form class="form" id="profile-form"><label>Nome de exibição<input name="name" maxlength="70" required></label>' +
    '<label>Área<select name="role"><option>Pedagogia</option><option>Fonoaudiologia</option><option>Outra área</option></select></label>' +
    '<label>Apresentação<textarea name="bio" rows="3" maxlength="280"></textarea></label><button class="button primary">Pré-visualizar perfil</button></form>');
}

document.querySelector('#profiles').innerHTML = people.map((person, index) =>
  '<article class="profile"><span class="avatar" aria-hidden="true">' + person.initials + '</span><div><h3>' + person.name +
  '</h3><p class="label">' + person.role + '</p></div><p class="bio">' + person.bio + '</p>' +
  '<button type="button" class="text-link" data-person="' + index + '">Ver perfil e lojinha</button></article>').join('');
query.addEventListener('input', renderCatalog);
document.querySelector('#filters').addEventListener('click', event => {
  const button = event.target.closest('[data-filter]');
  if (!button) return;
  selectedFilter = button.dataset.filter;
  for (const chip of event.currentTarget.querySelectorAll('[data-filter]')) chip.setAttribute('aria-pressed', String(chip === button));
  renderCatalog();
});
document.querySelector('#my-space').addEventListener('click', viewFavorites);
document.querySelector('#publish').addEventListener('click', publish);
document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button) return;
  const { save, item, person } = button.dataset;
  if (save) {
    if (saved.has(save)) saved.delete(save);
    else saved.add(save);
    button.setAttribute('aria-pressed', String(saved.has(save)));
    try { localStorage.setItem('miudoverso:saved', JSON.stringify([...saved])); } catch {}
  }
  if (item) openMaterial(item);
  if (person !== undefined) viewProfile(Number(person));
  if (button.hasAttribute('data-buy')) dialogBody.querySelector('[role=status]').textContent = 'Simulação concluída. Nenhum pagamento foi realizado.';
  if (button.hasAttribute('data-report')) report();
  if (button.id === 'profile-preview') editProfile();
});
dialog.addEventListener('submit', event => {
  const form = event.target;
  if (form.method === 'dialog') return;
  event.preventDefault();
  if (form.id === 'publish-form') {
    const file = form.elements.file.files[0];
    const feedback = form.querySelector('[role=status]');
    if (!file?.name.toLowerCase().endsWith('.pdf')) {
      feedback.textContent = 'Selecione um PDF.';
      return;
    }
    form.reset();
    feedback.textContent = 'Envio simulado. No piloto, o material poderia passar por revisão antes de aparecer no catálogo.';
  }
  if (form.id === 'report-form') {
    form.reset();
    form.querySelector('[role=status]').textContent = 'Simulação concluída. Nenhuma denúncia foi enviada.';
  }
  if (form.id === 'profile-form') {
    const model = new FormData(form);
    show('Prévia do seu perfil', '<h3 id="name-preview"></h3><p class="label" id="role-preview"></p><p id="bio-preview"></p><p class="demo">Perfil temporário para demonstração.</p>');
    for (const field of ['name','role','bio']) document.querySelector('#' + field + '-preview').textContent = model.get(field);
  }
});
document.querySelector('#waitlist').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button');
  const feedback = form.querySelector('[role=status]');
  const data = Object.fromEntries(new FormData(form));
  button.disabled = true;
  feedback.textContent = 'Enviando sua inscrição…';
  try {
    const response = await fetch('/api/lista-de-espera', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ ...data, consent:data.consent === 'on' })
    });
    const payload = await response.json();
    feedback.textContent = payload.message;
    if (response.ok) form.reset();
  } catch {
    feedback.textContent = 'Não foi possível confirmar a inscrição. Tente novamente.';
  } finally {
    button.disabled = false;
  }
});
renderCatalog();

